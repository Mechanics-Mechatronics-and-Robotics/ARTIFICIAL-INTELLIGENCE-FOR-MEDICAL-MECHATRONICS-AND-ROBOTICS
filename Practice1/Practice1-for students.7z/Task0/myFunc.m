function [sum,dif] = myFunc(A,B)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
sum=A+B;
dif=A-B;
end

