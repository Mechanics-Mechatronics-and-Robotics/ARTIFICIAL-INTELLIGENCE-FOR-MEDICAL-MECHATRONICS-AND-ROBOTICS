clear
clc

%% 0. Settings

%Mechanics
cartSize=[0.02 0.01 0.01];% cart size 
poleSize=[0.01 0.01 0.1];% pole size
randRotation=rand*20;% random rotation of the pole