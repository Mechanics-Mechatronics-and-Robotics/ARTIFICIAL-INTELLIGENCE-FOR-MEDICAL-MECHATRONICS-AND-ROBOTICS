function plot_data(x)

n1=find(x(:,end)==1);
n2=find(x(:,end)==0);
figure; hold on;
plot(x(n1,1),x(n1,2),'b+');
plot(x(n2,1),x(n2,2),'ro','MarkerSize',7);
hold off;
xlabel('X1');
ylabel('X2');
end