function [X_new] = MatrixFeatures(X, d)
  [n,m] = size(X);
  X_new = ones(n,1);
  for i=1:d
    for j=0:i
     X_new(:,end+1) = 
    end
  end
end
