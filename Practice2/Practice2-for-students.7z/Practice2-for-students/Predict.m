function [Y_t, acc] = Predict(Th, X, Y)
  H=
  Y_t=
  acc= 
end
