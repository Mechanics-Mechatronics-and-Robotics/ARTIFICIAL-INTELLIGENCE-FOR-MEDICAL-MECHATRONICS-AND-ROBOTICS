clc; clear;

load('Input_data.mat');
N=length(data);
n_tr=60;
n_v=30;
n_ts=N-n_tr-n_v;
degree=2; %degree=[2 4 6 8 10]
lambda=0.1;%lambda=[0 0.01 0.1 0.5 1]

plot_data(data);

num=
%Training data:
X_tr=
Y_tr=

%Validation data:
X_v=
Y_v=

%Testing data:
X_ts=
Y_ts=


[X_tr] = MatrixFeatures(X_tr, degree);
Th0=zeros(size(X_tr,2),1);
[J0, Gr0] = CostFunctionReg(X_tr, Y_tr, Th0, lambda);

option=optimset('GradObj','on','MaxIter',400);
[Theta, J]=fminunc(@(t)(CostFunctionReg(X_tr, Y_tr, t, lambda)), Th0, option);

%Testing:
[X_ts] = MatrixFeatures(X_ts, degree);
[Yt_tr, acc_tr] = Predict(Theta, X_tr, Y_tr);
[Yt_ts, acc_ts] = Predict(Theta, X_ts, Y_ts);

