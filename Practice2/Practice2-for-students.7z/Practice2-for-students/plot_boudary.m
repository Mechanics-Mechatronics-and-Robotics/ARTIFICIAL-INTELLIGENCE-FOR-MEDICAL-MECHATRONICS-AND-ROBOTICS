function plot_boudary(th,XX,degree)
  n=50;
  X1 = linspace(min(XX(:,1)),max(XX(:,1)),n);
  X2 = linspace(min(XX(:,2)),max(XX(:,2)),n);
  X=[X1' X2'];
    for i = 1:n
        for j = 1:n
            z(i,j) = mapFeature([X(i) X(j)],degree)*th;
        end
    end
  z=z';
  contour(X1, X2, z, [0, 0], 'LineWidth', 2);
endfunction
