function [J, Gr] = CostFunctionReg(X, Y, Th, la)
  [n,m] = size(X);
  J=0;
  Gr=zeros(n,1);
  H=
  J=
  
  Gr=
  Gr(1,1)=
  
end
